import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  HomePage({super.key});

  final List<IconData> icons = [
    Icons.chair,
    Icons.mobile_off,
    Icons.settings,
    Icons.wifi,
    Icons.pets,
    Icons.arrow_back,
    Icons.heart_broken,
    Icons.male,
    Icons.female,
  ];
  final List<Color> colors = [
    Colors.amber,
    Colors.yellow,
    Colors.green,
    Colors.purple,
    Colors.red,
    Colors.blueGrey,
    Colors.cyan,
    Colors.pinkAccent,
    Colors.indigo,
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Grid view')),
      body: Center(
        child: Container(
          color: Colors.yellow,
          height: 800,
          padding: EdgeInsets.all(5),
          child: GridView.builder(
            itemCount: icons.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 10,
              crossAxisSpacing: 5,
            ),
            itemBuilder: (context, index) =>
                getWidget(color: Colors.blue, icon: icons[index]),

            //  scrollDirection: Axis.vertical,
            //   mainAxisSpacing: 5,
            //  crossAxisSpacing: 10,
            //   crossAxisCount: 2,
            //  children: [
            //    getWidget(color: Colors.amber, icon: Icons.chair),
            //    getWidget(color: Colors.yellow, icon: Icons.mobile_off),
            //   getWidget(color: Colors.green, icon: Icons.settings),
            //   getWidget(color: Colors.purple, icon: Icons.wifi),
            //    getWidget(color: Colors.red, icon: Icons.pets),
            //  getWidget(color: Colors.blueGrey, icon: Icons.arrow_back),
            //    getWidget(color: Colors.cyan, icon: Icons.heart_broken),
            //  getWidget(color: Colors.pinkAccent, icon: Icons.male),
            //  getWidget(color: Colors.indigo, icon: Icons.female),
            //  ],
          ),
        ),
      ),
    );
  }

  Widget getWidget({required Color color, required IconData icon}) {
    return Container(color: color, child: Icon(icon, size: 50));
  }
}
